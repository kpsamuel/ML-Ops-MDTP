# -*- coding: utf-8 -*-
"""
Created on Tue Jun 15 08:32:17 2021

@author: samuel
"""

import json
from pandas import Series
from numpy import array
import pickle
from sklearn.pipeline import Pipeline


with open("modelconfig.json", "r") as fp:
    modelconfig = json.load(fp)
    
modelpath = modelconfig["modelname"]
trained_label_encoder = modelconfig["trained_label_encoder"]

def loadTrainedObjects(filepath):
    with open(filepath, "rb") as fp:
        trained_object = pickle.load(fp)
        return trained_object
    
def prediction(x_feature):
    
    x_feature = array(Series(x_feature)).reshape(1, -1)
    linear_model = loadTrainedObjects(modelpath)
    trained_encoder = loadTrainedObjects(trained_label_encoder)
    
    model_pipeline = Pipeline(steps=[('classifier_model', linear_model)])
    predicted_label = model_pipeline.predict(X=x_feature)
    decoded_label = trained_encoder.inverse_transform(predicted_label)
    return decoded_label[0]

if __name__ == "__main__":
    with open(modelconfig["input_file_to_refer"], "r") as fp:
        input_features = json.load(fp)
    
    predicted_result = prediction(input_features)
    print("predicted : ", predicted_result)
    with open(modelconfig["predicted_file_to_refer"], "w") as fp:
        json.dump({"output":predicted_result}, fp)
